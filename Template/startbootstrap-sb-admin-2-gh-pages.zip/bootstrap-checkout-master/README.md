# Bootstrap Checkout Example

Bootstrap's documentation has a [beautiful example of a checkout](https://getbootstrap.com/docs/4.1/examples/checkout/), but folks shouldn't just copy and paste that in to their store.

This demo adds improved validation, provides correct number input on mobile devices, autocomplete and more.

Demo: https://coliff.github.io/bootstrap-checkout/
